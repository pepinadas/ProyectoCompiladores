# LYA_COMPILADOR_JAVA
Lenguajes y Automatas 

Requisitos:
- Instalar la versión Open JDK 11 LTS (https://adoptium.net/es/temurin/releases/?version=11)
- Instalar apache NetBeans (cualquier versión): (https://www.youtube.com/watch?v=zf0IodhRFqg&ab_channel=DirectoAlGrano)
- Windows (10/11) 64 bits

Descripción:
  Este es un compilador desarrollado en el lenguaje java el cual cuenta con una sintaxis similar a la de java y en algunos casos a la de python, también este compilador está enfocado al proyecto de una silla de ruedas inteligente, es por eso que en la documentación se hara mucho énfasis en esto. Cabe mencionar que este compilador cuenta con el análisis(léxico, sintáctico y semántico) además de traducir el código de alto nivel a código de 3 direcciones mediante tripletas para posteriormente traducirlo a código objeto y así finalmente traducirlo a lenguaje ensamblador, esto con el fin de utilizar dicho código y quemarlo en el pic8086.

Video:

[![Alt text](https://img.youtube.com/vi/2d-R9ufWMH0/0.jpg)](https://youtu.be/2d-R9ufWMH0)

(https://www.youtube.com/watch?v=2d-R9ufWMH0&ab_channel=PEDROFIGUEROARUIZ)
